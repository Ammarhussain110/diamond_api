const router = require("express").Router()

router.post('/test', async (req, res) => {
    
})

module.exports = router