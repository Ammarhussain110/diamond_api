const router = require("express").Router()

const User = require("../model/user")

router.post('/test', async (req, res) => {
   try {
       
   } catch (error) {
       
   }
})

module.exports = router