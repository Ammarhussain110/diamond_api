const router = require("express").Router()

const User = require("../model/user")

router.post('/test', async (req, res) => {
   tr
})

module.exports = router